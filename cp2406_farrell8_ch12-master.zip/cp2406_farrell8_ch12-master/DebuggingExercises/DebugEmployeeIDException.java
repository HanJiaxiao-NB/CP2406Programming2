public class DebugEmployeeIDException extends Exception
{
   public DebugEmployeeIDException()
   {
      super(s);
   }
}


