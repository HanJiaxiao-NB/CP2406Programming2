public class ToolTipDemo
{
   public static void main(String[] args)
   {
      JFrameWithToolTip frame =
         new JFrameWithToolTip();
      frame.setVisible(true);
   }
}
