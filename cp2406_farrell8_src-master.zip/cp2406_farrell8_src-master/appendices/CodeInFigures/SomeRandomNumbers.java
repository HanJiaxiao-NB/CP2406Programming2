public class SomeRandomNumbers
{
   public static void main (String[] args)
   {
      double ran;
      ran = Math.random();
      System.out.println(ran);
      ran = Math.random();
      System.out.println(ran);
      ran = Math.random();
      System.out.println(ran); 
   }
}
