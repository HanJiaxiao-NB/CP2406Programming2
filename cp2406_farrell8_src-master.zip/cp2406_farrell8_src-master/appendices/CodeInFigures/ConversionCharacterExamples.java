public class ConversionCharacterExamples
{
   public static void main(String[] args)
   {
      int age = 23;
      double money = 123.45;
      System.out.printf("Age is %d\n", age);
      System.out.printf("Money is $%f\n", money);
      System.out.printf
         ("Age is %d and money is $%f\n", age, money);
   }
}
