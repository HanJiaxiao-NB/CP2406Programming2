public class BaseballPlayer
{
   private int jerseyNumber;
   private double battingAvg;
   public static void showOrigins()
   {
      System.out.println("Abner Doubleday is often " +
         "credited with inventing baseball");
   }
}
