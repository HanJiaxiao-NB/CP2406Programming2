public class DebugVacation
{
   private int days;
   public DebugVacation()
   {
      days = 10;
   }
   public int getDays()
   {
      return days;
   }
}
