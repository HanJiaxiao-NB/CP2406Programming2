public class DebugOne33
{
   public static void main(String[] args)
   {
      System.Out.println("Over the river");
      system.out.println("and through the woods");
      SysTem.0ut.println("to Grandmother's house we go");
   }
}