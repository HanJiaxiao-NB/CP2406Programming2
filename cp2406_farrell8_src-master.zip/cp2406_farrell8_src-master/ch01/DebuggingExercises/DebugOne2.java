public class DebugOne2
{
   /* This program displays some output
   public static void main(String args)
   {
      System.out.println("Java programming is fun.");
      System.out.println("Getting a program to work");
      System.out.println("can be a challenge,");
      System.out.prnitln("but when everything works correctly,");
      System.out.println("tt's very satisfying");
   }
}