// Instantiates Rowboat
// Rowboat is child of Boat
public class DebugEleven1
{
   public static void main(String[] args)
   {
      DebugRowboat myBoat = new Rowboat();
      System.out.println(myBoat.toString());
   }
}
