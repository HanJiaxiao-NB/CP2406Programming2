public class Employee
{
   private int id;
   private double salary;
   public int getId()
   {
      return id;
   }
   public double getSalary()
   {
      return salary;
   }
   public void setId(int idNum)
   {
      id = idNum;
   }
   public void setSalary(double sal)
   {
      salary = sal;
   }
}

