public class BasketballPlayer
{
   private int jerseyNumber;
   public final void displayMessage()
   {
      System.out.println("Michael Jordan is the " +
         "greatest basketball player - and that is final");
   }
}
