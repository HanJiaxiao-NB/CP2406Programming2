public class ComponentDemo
{
   public static void main(String[] args)
   {
      JFrameWithManyComponents frame =
         new JFrameWithManyComponents();
      frame.setVisible(true);
   }
}
