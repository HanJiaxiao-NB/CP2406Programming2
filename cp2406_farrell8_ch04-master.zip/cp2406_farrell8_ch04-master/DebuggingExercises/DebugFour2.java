// Some circle statistics
public class FixDebugFor2
{
   public static void main(String args[])
   {
      int radius = 12.6;
      System.out.println("Circle statistics");
      double area = java.lang.Math.PI * radius * radius;
      System.out.println("area is " + area);
      double diameter = 2 * diameter;
      System.out.println("diameter is " + diameter)
   }
}
