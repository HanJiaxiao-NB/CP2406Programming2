// FavoriteSong.java
// Chapter 1, Exercise #9
// Displays learning objectives

class FavoriteSong
{
   public static void main(String[] args)
   {
      System.out.println("Somewhere over the rainbow");
      System.out.println("Way up high");
      System.out.println("There's a land that I heard of");
      System.out.println("Once in a lullaby");
   }
}
