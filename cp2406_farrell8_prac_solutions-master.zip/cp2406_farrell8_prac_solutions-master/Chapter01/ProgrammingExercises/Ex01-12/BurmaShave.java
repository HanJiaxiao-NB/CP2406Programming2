// BurmaShave.java
// Chapter 1, Exercise #12
// Displays Burma Shave slogan
import javax.swing.JOptionPane;

class BurmaShave
{
   public static void main(String[] args)
   {
      JOptionPane.showMessageDialog(null,"Shaving brushes");
      JOptionPane.showMessageDialog(null,"You'll soon see 'em");
      JOptionPane.showMessageDialog(null,"On a shelf");
      JOptionPane.showMessageDialog(null,"In some museum");
      JOptionPane.showMessageDialog(null,"Burma Shave");
      System.exit(0); 
   }
}