public class CarlysMotto
{
   public static void main(String[] args)
   {
      System.out.println("Carly's makes the food that makes it a party.");
   }
}
