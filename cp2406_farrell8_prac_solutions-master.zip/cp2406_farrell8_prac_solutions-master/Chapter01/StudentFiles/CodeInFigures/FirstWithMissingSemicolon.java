public class FirstWithMissingSemicolon
{
   public static void main(String[] args)
   {
      System.out.println("First Java application")
   }
}
