public class IgneousRock extends Rock
{
   public IgneousRock(int num, double grams)
   {
      super(num, grams);
      setDescription("Igneous rocks are crystalline solids " +
         "\nwhich form directly from the cooling of magma.");
   }
}
