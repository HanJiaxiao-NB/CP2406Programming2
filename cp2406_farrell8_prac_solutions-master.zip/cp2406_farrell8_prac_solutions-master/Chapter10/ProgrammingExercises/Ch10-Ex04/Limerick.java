public class Limerick extends Poem
{
   private String title;
   private int lines;
   public Limerick(String name)
   {
      super(name, 5);
   }
}
