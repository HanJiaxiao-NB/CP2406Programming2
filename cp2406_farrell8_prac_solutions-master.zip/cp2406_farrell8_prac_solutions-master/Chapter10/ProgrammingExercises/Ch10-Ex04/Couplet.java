public class Couplet extends Poem
{
   private String title;
   private int lines;
   public Couplet(String name)
   {
      super(name, 2);
   }
}
