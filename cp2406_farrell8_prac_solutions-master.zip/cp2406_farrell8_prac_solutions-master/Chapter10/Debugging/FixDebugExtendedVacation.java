public class FixDebugExtendedVacation extends FixDebugVacation
{
   public FixDebugExtendedVacation()
   {
      days = 30;
   }
}