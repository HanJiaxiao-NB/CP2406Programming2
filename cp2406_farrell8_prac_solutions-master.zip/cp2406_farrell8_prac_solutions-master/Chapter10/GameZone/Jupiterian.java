import javax.swing.*;
import java.awt.*;
public class Jupiterian extends Alien
{
   public Jupiterian()
   {
      super(2, 8, 2);
   }
}